import { StyleSheet, Text, View } from 'react-native';

const ProfileScreen = () => {
    return (
        <View>
            <Text>Profile</Text>
        </View>
    );
}

const styles = StyleSheet.create({})

export default ProfileScreen;
