import axios from "axios";

export const api = axios.create({ baseURL: "http://26.195.11.246:4000" });
