import { api } from "../config/api";

export const getProducts = async () => {
  const { data } = await api.get("/products");
  return data.data;
};

export const getProductById = async (id) => {
  const { data } = await api.get(`/products/${id}`);
  return data;
};
